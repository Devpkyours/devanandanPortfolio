import React from 'react';

function Projects() {
  return (
    <section id="projects">
      <h2>Projects</h2>
      <div className="project">
        <h3>Food Delivery App (Apr 2024)</h3>
        <p>Built with React JS | Responsive UI | Search & Filter | Order Flow</p>
      </div>
      <div className="project">
        <h3>WishDev E-Commerce Website (Sep 2023)</h3>
        <p>Built with React JS | Add to Cart | Wishlist | Product Filtering</p>
      </div>
    </section>
  );
}

export default Projects;