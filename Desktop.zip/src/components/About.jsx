import React from 'react';

function About() {
  return (
    <section id="about">
      <h2>About Me</h2>
      <p>I’m a B.Tech Computer Science (AIML) student with hands-on experience in frontend development and real-world projects. I’m passionate about building scalable and responsive web applications using modern technologies.</p>
      <p><strong>Skills:</strong> Java, ReactJS, HTML, CSS, JavaScript, SQL, MySQL, Data Structures, Problem Solving</p>
    </section>
  );
}

export default About;