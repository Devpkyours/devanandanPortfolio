import React from 'react';

function Experience() {
  return (
    <section id="experience">
      <h2>Experience</h2>
      <div className="experience">
        <h3>Frontend Developer Intern – Nextag Media Pvt. Ltd. (Jan – June 2024)</h3>
        <ul>
          <li>Built responsive pages with HTML, CSS, JS, React</li>
          <li>Developed sliders, modals, and dynamic forms</li>
          <li>Focused on UI design and responsive layout</li>
        </ul>
      </div>
    </section>
  );
}

export default Experience;