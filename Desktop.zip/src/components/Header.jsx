import React from 'react';

function Header() {
  return (
    <header className="header">
      <h1>Hi, I'm Devanandan Anand</h1>
      <p>Frontend Developer | Java Enthusiast | Problem Solver</p>
      <a href="https://drive.google.com/file/d/1CiyYhsF5840rzFPA26hM3rc-lfEEkUeh/view?usp=sharing" className="btn">Download Resume</a>
    </header>
  );
}

export default Header;