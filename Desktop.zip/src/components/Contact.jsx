import React from 'react';

function Contact() {
  return (
    <section id="contact">
      <h2>Contact Me</h2>
      <p>Email: <a href="mailto:devanandan.anand@gmail.com">devanandan.anand@gmail.com</a></p>
      <p>Phone: +91-9279230411</p>
      <p>LinkedIn: <a href="https://linkedin.com/in/devanandan-anand-8821ba203" target="_blank">linkedin.com/in/devanandan-anand</a></p>
    </section>
  );
}

export default Contact;