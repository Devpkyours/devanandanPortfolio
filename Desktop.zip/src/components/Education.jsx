import React from 'react';

function Education() {
  return (
    <section id="education">
      <h2>Education</h2>
      <div className="education">
        <h3>Lakshmi Narain College of Technology Excellence, Bhopal</h3>
        <p>B.Tech – Computer Science (AIML) | CGPA: 7.41 | 2022–2025</p>
        <p><strong>Certificate:</strong> Cisco Network Support and Security</p>
      </div>
    </section>
  );
}

export default Education;